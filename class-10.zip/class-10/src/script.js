const KEY = "AIzaSyDpkSD8ll9m_9_PIzVgWiOMn2jL-j8Yx14";

// 50-QUESTION PYQ DATABASE
const questions = {
    science: [    science: [
        // CHEMISTRY (Chemical Reactions, Acids/Bases, Metals, Carbon)
        {q: "Why is magnesium ribbon cleaned before burning?", a: ["To remove oxide layer", "To make it burn slower", "To increase weight", "To change color"], c: 0},
        {q: "Formula of Bleaching Powder?", a: ["CaCO3", "CaOCl2", "Ca(OH)2", "CaCl2"], c: 1},
        {q: "Which gas is evolved when Zn reacts with HCl?", a: ["O2", "CO2", "H2", "Cl2"], c: 2},
        {q: "pH of a neutral solution is?", a: ["0", "7", "1", "14"], c: 1},
        {q: "Non-metal which is liquid at room temperature?", a: ["Mercury", "Bromine", "Iodine", "Chlorine"], c: 1},
        {q: "Which acid is present in tomato?", a: ["Methanoic acid", "Citric acid", "Oxalic acid", "Tartaric acid"], c: 2},
        {q: "Main component of CNG?", a: ["Ethane", "Methane", "Propane", "Butane"], c: 1},
        {q: "Rusting of iron is which type of reaction?", a: ["Reduction", "Redox", "Decomposition", "None"], c: 1},
        {q: "Butanone is a 4-carbon compound with group:", a: ["Carboxylic acid", "Aldehyde", "Ketone", "Alcohol"], c: 2},
        {q: "Element used in making solar cells?", a: ["Gold", "Silicon", "Silver", "Aluminum"], c: 1},
        {q: "The hardest natural substance is?", a: ["Iron", "Diamond", "Graphite", "Gold"], c: 1},
        {q: "Aqua Regia is a mixture of HCl and HNO3 in ratio:", a: ["1:3", "3:1", "2:2", "1:1"], c: 1},
        {q: "Cinnabar is an ore of which metal?", a: ["Copper", "Mercury", "Iron", "Zinc"], c: 1},
        {q: "Food cans are coated with tin, not zinc because:", a: ["Zn is costlier", "Zn is more reactive", "Zn has higher MP", "Zn is less reactive"], c: 1},
        {q: "Propane formula?", a: ["C3H8", "C2H6", "CH4", "C4H10"], c: 0},

        // PHYSICS (Light, Human Eye, Electricity, Magnetism)
        {q: "Mirror used as rear-view in vehicles?", a: ["Concave", "Plane", "Convex", "Bifocal"], c: 2},
        {q: "Power of lens with focal length 2m?", a: ["0.5 D", "2 D", "1 D", "0.2 D"], c: 0},
        {q: "The human eye forms the image at?", a: ["Cornea", "Iris", "Pupil", "Retina"], c: 3},
        {q: "S.I. unit of resistivity?", a: ["Ohm", "Ohm-meter", "Volt", "Ampere"], c: 1},
        {q: "Device used to measure electric current?", a: ["Voltmeter", "Ammeter", "Galvanometer", "Generator"], c: 1},
        {q: "The least distance of distinct vision?", a: ["25 m", "25 cm", "2.5 cm", "Infinity"], c: 1},
        {q: "Refractive index of diamond?", a: ["1.33", "1.50", "2.42", "1.00"], c: 2},
        {q: "Splitting of white light into 7 colors is?", a: ["Reflection", "Refraction", "Dispersion", "Scattering"], c: 2},
        {q: "Near-sightedness is called?", a: ["Hypermetropia", "Myopia", "Presbyopia", "Cataract"], c: 1},
        {q: "Commercial unit of electrical energy?", a: ["Joule", "Watt", "kWh", "Volt"], c: 2},
        {q: "Magnetic field lines emerge from?", a: ["South Pole", "North Pole", "Center", "None"], c: 1},
        {q: "Device that converts Electrical to Mechanical energy?", a: ["Generator", "Motor", "Battery", "Switch"], c: 1},
        {q: "Who discovered Electromagnetic Induction?", a: ["Ampere", "Faraday", "Ohm", "Newton"], c: 1},
        {q: "Color of sky from Moon?", a: ["Blue", "Red", "Black", "White"], c: 2},
        {q: "Focal length of plane mirror?", a: ["Zero", "25 cm", "Infinity", "1 m"], c: 2},
        {q: "Formula for Ohm's Law?", a: ["V = I/R", "V = IR", "R = VI", "I = V+R"], c: 1},

        // BIOLOGY (Life Processes, Control/Coord, Reproduction, Heredity)
        {q: "Site of photosynthesis in plants?", a: ["Mitochondria", "Chloroplast", "Nucleus", "Ribosome"], c: 1},
        {q: "Basic unit of kidney?", a: ["Neuron", "Nephron", "Alveoli", "Villi"], c: 1},
        {q: "Xylem in plants is responsible for:", a: ["Food", "Water", "Amino acids", "Oxygen"], c: 1},
        {q: "Gap between two neurons?", a: ["Dendrite", "Axon", "Synapse", "Impulse"], c: 2},
        {q: "Which hormone regulates blood sugar?", a: ["Adrenaline", "Insulin", "Thyroxine", "Estrogen"], c: 1},
        {q: "Amoeba reproduces through?", a: ["Budding", "Binary Fission", "Fragmentation", "Spores"], c: 1},
        {q: "Father of Genetics?", a: ["Darwin", "Mendel", "Lamarck", "Morgan"], c: 1},
        {q: "Male reproductive part of flower?", a: ["Sepal", "Petal", "Stamen", "Carpel"], c: 2},
        {q: "Number of pairs of chromosomes in humans?", a: ["21", "22", "23", "46"], c: 2},
        {q: "Part of brain for balance?", a: ["Cerebrum", "Cerebellum", "Medulla", "Pons"], c: 1},
        {q: "Plant hormone that inhibits growth?", a: ["Auxin", "Gibberellin", "Cytokinin", "Abscisic acid"], c: 3},
        {q: "Unit of Inheritance?", a: ["DNA", "Gene", "Chromosome", "Nucleus"], c: 1},
        {q: "Which organism shows budding?", a: ["Yeast", "Amoeba", "Plasmodium", "Leishmania"], c: 0},
        {q: "Example of homologous organs?", a: ["Wing of bird & bat", "Human arm & Bird wing", "Wing of insect & bird", "None"], c: 1},
        {q: "Energy currency of the cell?", a: ["ADP", "ATP", "AMP", "Pyruvate"], c: 1},
        {q: "Ozone layer protects us from?", a: ["Infrared", "X-rays", "UV rays", "Gamma rays"], c: 2},
        {q: "Primary consumer in a food chain?", a: ["Lion", "Snake", "Deer", "Tiger"], c: 2},
        {q: "Blood pressure is measured by?", a: ["Stethoscope", "Sphygmomanometer", "Thermometer", "Ammeter"], c: 1},
        {q: "Enzyme present in saliva?", a: ["Pepsin", "Trypsin", "Amylase", "Lipase"], c: 2}
    ]

        {q: "Why is magnesium ribbon cleaned before burning?", a: ["To remove MgO layer", "To make it burn slower", "To increase weight", "To change color"], c: 0},
        {q: "Formula of Bleaching Powder?", a: ["CaCO3", "CaOCl2", "Ca(OH)2", "CaCl2"], c: 1},
        {q: "Which gas is evolved when Zn reacts with HCl?", a: ["O2", "CO2", "H2", "Cl2"], c: 2},
        {q: "PH of acidic solution is?", a: ["7", "Less than 7", "More than 7", "14"], c: 1},
        {q: "Mirror used by dentists?", a: ["Convex", "Plane", "Concave", "Bifocal"], c: 2},
        {q: "S.I unit of Electric Current?", a: ["Volt", "Ampere", "Ohm", "Watt"], c: 1},
        // ... (I have the other 44 saved, ready to add)
    ],
    maths: [
        {q: "Product of zeros of x^2 + 7x + 10?", a: ["7", "-7", "10", "-10"], c: 2},
        {q: "Value of sin 30?", a: ["1", "1/2", "√3/2", "0"], c: 1}
    ]
};

let currentQ = 0;
let currentSub = "";

function showSection(id) {
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
}

async function askAI() {
    const inp = document.getElementById('ai-input');
    const box = document.getElementById('chat-box');
    if(!inp.value) return;
    
    box.innerHTML += `<div class='text-right ml-10 mb-2'><span class='bg-blue-600 text-white p-2 rounded-lg inline-block'>${inp.value}</span></div>`;
    const prompt = inp.value;
    inp.value = "";

    try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${KEY}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({contents:[{parts:[{text: "Act as Class 10 Teacher. Answer: " + prompt}]}]})
        });
        const data = await res.json();
        const reply = data.candidates[0].content.parts[0].text;
        box.innerHTML += `<div class='text-left mr-10 mb-2'><span class='glass p-2 rounded-lg inline-block'>${reply}</span></div>`;
        box.scrollTop = box.scrollHeight;
    } catch(e) { box.innerHTML += `<p class='text-red-500'>Connection Error</p>`; }
}

function startQuiz(sub) {
    currentSub = sub;
    currentQ = 0;
    document.getElementById('quiz-menu').classList.add('hidden');
    document.getElementById('quiz-screen').classList.remove('hidden');
    loadQuestion();
}

function loadQuestion() {
    const qData = questions[currentSub][currentQ];
    document.getElementById('q-subject').innerText = currentSub.toUpperCase();
    document.getElementById('q-progress').innerText = `${currentQ + 1}/${questions[currentSub].length}`;
    document.getElementById('q-text').innerText = qData.q;
    
    const optBox = document.getElementById('options');
    optBox.innerHTML = "";
    qData.a.forEach((opt, i) => {
        const btn = document.createElement('button');
        btn.className = "w-full p-4 glass text-left hover:bg-blue-50 transition";
        btn.innerText = opt;
        btn.onclick = () => {
            if(i === qData.c) alert("Correct! 🎉");
            else alert("Wrong! Correct answer: " + qData.a[qData.c]);
            
            currentQ++;
            if(currentQ < questions[currentSub].length) loadQuestion();
            else {
                alert("Quiz Finished!");
                showSection('home');
                document.getElementById('quiz-menu').classList.remove('hidden');
                document.getElementById('quiz-screen').classList.add('hidden');
            }
        };
        optBox.appendChild(btn);
    });
}
